import java.util.Scanner;
public class Client{
    public static void main1(){
        Program1 p=new Program1();
        System.out.println("I am main1");
        p.go();
    }

    public static void main2(){
        Program2 p=new Program2();
        System.out.println("I am main2");
        p.go();
    }

    public static void main3(){
        Program3 p=new Program3();
        System.out.println("I am main3");
        p.go();
    }

    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.printf("Choose a number 1 or 2 or 3 :");
        int input=sc.nextInt();
        if(input==1){
            main1();
        }
        else if(input==2){
            main2();
        }
        else{
            main3();
        }
        
        
        
    }
}

class Program1{
    public Program1(){}
    public void go(){
        System.out.println("Je suis le traitement 1 ");
    }
    
}

class Program2{
    public Program2(){}
        public void go(){
            System.out.println("Je suis le traitement 2 ");
        }
    
}

class Program3{
    public Program3(){}
        public void go(){
            System.out.println("Je suis le traitement 3 ");
        }
    
}