
class Database {
    private String name;
    private static Database instance = null;
    // Private constructor
    private Database(String name) {
        this.name = name;
    }
    // Singleton method
    public static Database getInstance(String name) {
        if (instance==null) {
            instance=new Database(name);
        }
        return instance;
    }

    public void getConnection() {
        System.out.println("You are connected to the database " + name);
    }


    public static void main(String[] args) {
        Database db1=Database.getInstance("MySQL");
        Database db2=Database.getInstance("Oracle");

        db1.getConnection();
        db2.getConnection();
        //Since we already create the first instance db1 that gives as an output "You are connected to the database MySQL"
        //When we tried to create a second one the condition if(instance == null) is not true anymore
        //So we just keep the first instance

        System.out.println(db1 == db2);
    
    }
}
