public interface MusicPlayer{
    public boolean play(String artist, String title);
}