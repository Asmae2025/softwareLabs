import java.util.*;
public class NestedMissions implements Mission{
    String name;
    List<Mission> missions;

    public NestedMissions(String name){
        this.name=name;
        missions=new ArrayList<>();
    }
    public void add(Mission mission) {
        missions.add(mission);
    }
    public void remove(Mission mission) {
        missions.remove(mission);
    }

    public void display(String indent) {

        System.out.println(indent + name);

        for (Mission m : missions) {
            m.display(indent + "    ");
        }
    }
    public int getDuration() {

        int total = 0;

        for (Mission m : missions) {
            total += m.getDuration();
        }

        return total;
    }
}