public class SimpleMission implements Mission{
    public String name;
    public int duration;

    public SimpleMission(String name,int duration){
        this.name=name;
        this.duration=duration;
    }

    public void display(String indent){
        System.out.println(indent+" Duration : "+duration);
    }
    public int getDuration(){
        return duration;
    }


}