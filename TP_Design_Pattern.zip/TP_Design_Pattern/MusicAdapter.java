public class MusicAdapter implements MusicPlayer {
    LegacyMusicPlayer legacyplayer;
    public MusicAdapter(LegacyMusicPlayer legacyplayer){
        this.legacyplayer=legacyplayer;
    }
    public boolean play(String artist, String title){
        if(artist==null||artist.trim().isEmpty()||title==null||title.trim().isEmpty()){
            return false;
        }
        String track =artist+" - "+title;
        
        return legacyplayer.playTrack(track)==1;
    }

}