public class MainMission {
    public static void main(String[] args) {

        // Create simple missions
        Mission checkFuel = new SimpleMission("Check fuel", 5);
        Mission loadRobots = new SimpleMission("Load robots", 10);
        Mission deploy = new SimpleMission("Deploy", 8);

        // Create Preparation group
        NestedMissions preparation = new NestedMissions("Preparation");

        preparation.add(checkFuel);
        preparation.add(loadRobots);

        // Create root mission
        NestedMissions launch = new NestedMissions("Launch Operation");

        launch.add(preparation);
        launch.add(deploy);

        // Display hierarchy
        launch.display("");

        // Calculate total duration
        System.out.println("Total duration: "
                + launch.getDuration() + " minutes");
    }
}