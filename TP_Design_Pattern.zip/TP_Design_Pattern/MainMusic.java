public class MainMusic{
    public static void main(String[] args){
        LegacyMusicPlayer legacy=new LegacyMusicPlayer();
        MusicPlayer player1=new MusicAdapter(legacy);

        System.out.println(player1.play("Artist1","song1"));

        StreamingPlayer stream=new StreamingPlayer();
        MusicPlayer player2=new StreamingAdapter(stream);
        System.out.println(player2.play("Artist2","song2"));
    }
}