public interface Mission{
    void display(String indent);
    int getDuration();
}