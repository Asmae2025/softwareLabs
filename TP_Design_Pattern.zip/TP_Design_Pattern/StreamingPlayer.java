public class StreamingPlayer{
    public boolean stream(Track track){
        if(track.getArtist()==null||track.getArtist().trim().isEmpty()||track.getTitle()==null||track.getTitle().trim().isEmpty()||track ==null){
            return false;
        }
        System.out.println("[Streaming Player] "+ track.getTitle()+" - "+track.getArtist());

        return true;
    }
}