public class StreamingAdapter implements MusicPlayer{
    StreamingPlayer streamingplayer;
    public StreamingAdapter(StreamingPlayer streamingplayer){
        this.streamingplayer=streamingplayer;
        
    }

    public boolean play(String artist, String title){
        Track track=new Track(title,artist);
        return streamingplayer.stream(track);
    }
}