public class Track{
    private String artist;
    private String title;

    public Track(String artist,String title){
        this.artist=artist;
        this.title=title;
    }
    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }



}